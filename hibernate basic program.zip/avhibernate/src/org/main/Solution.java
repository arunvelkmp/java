package org.main;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Solution {

	public static void main(String[] args) {
	users user=new users();
	user.setFirstName("Arunvel");
	user.setLastName("Kumaravel");
	user.setMobno("7373833192");
	user.setEmi("231");
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session session=sf.openSession();
	session.beginTransaction();
	session.save(user);
	session.getTransaction();
	session.save(user);
	session.getTransaction().commit();
	
		
	}

}
