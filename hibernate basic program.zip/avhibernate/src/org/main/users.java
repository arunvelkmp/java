package org.main;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class users {
	@Id
	private String FirstName;
	private String LastName;
	private String Mobno;
	private String emi;
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public void setMobno(String mobno) {
		Mobno = mobno;
	}
	public void setEmi(String emi) {
		this.emi = emi;
	}
	public String getFirstName() {
		return FirstName;
	}
	public String getLastName() {
		return LastName;
	}
	public String getMobno() {
		return Mobno;
	}
	public String getEmi() {
		return emi;
	}
	
	

}
