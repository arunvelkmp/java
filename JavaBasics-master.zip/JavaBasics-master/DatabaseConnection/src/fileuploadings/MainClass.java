package fileuploadings;

public class MainClass 
{

	public static void main(String[] args) throws Exception 
	{
        FeedBack dao = new FeedBack ();
        dao.readDataBase();
	}
}
