import package1.ClassOne;
import package2.ClassTwo;
 
public class Testing {
    public static void main(String[] args){
        ClassOne a = new ClassOne();
        ClassTwo b = new ClassTwo();
        a.methodClassOne();
        b.methodClassTwo();
    }
}