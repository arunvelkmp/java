package FinalExamples;

public class FinalVaraible1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// final keyword is used to make a variable final (constant) and the value of final variable can�t be changed.
		
		final int hours=24;
		

	      System.out.println("Hours in 6 days = " + hours * 6);

	}

}
