package OtherInheritance;

/**
 * This class represents a A grade college.
 * @author Rags
 */
public class College1 implements AGradeCollegeMarker{
	//Do something
}
