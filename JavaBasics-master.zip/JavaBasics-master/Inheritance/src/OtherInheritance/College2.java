package OtherInheritance;

/**
 * This class represents a, non A grade college.
 * @author Rags
 */
public class College2 {
	//Do something
}
