package OtherInheritance;

/**
 * This is marker interface for A grade college.
 * @author Rags
 */
public interface AGradeCollegeMarker {

}
