package TypesofInheritance;

public interface interfacepack {

}
