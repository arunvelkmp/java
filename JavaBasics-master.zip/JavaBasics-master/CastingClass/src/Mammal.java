
// Mammal > Animal > Dog, Cat

public interface Mammal 
{
	public void eat();
	 
    public void move();
 
    public void sleep();
}
