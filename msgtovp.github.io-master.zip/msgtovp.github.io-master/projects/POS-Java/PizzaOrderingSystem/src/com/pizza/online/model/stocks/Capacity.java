package com.pizza.online.model.stocks;

public enum Capacity {
	REGULAR, MEDIUM, LARGE;
}
