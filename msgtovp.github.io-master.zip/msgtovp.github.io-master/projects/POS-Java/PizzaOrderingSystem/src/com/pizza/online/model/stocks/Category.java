package com.pizza.online.model.stocks;

public enum Category {
	VEG, NON_VEG;
}
