package com.rags.primitive;

/*
public class Employee{
	private int EmployeeId;
	private String EmployeeName;
	private double EmployeeSalary;
	 
	public void setEmployeeId(int EmployeeId)
	{
	    this.EmployeeId = EmployeeId;
	}
	public int getEmployeeId()
	{
	    return EmployeeId;
	}
	 
	public void setEmployeeName(String EmployeeName)
	{
	    this.EmployeeName = EmployeeName;
	}
	public String getEmployeeName()
	{
	    return EmployeeName;
	}
	 
	public void setEmployeeSalary(double EmployeeSalary)
	{
	    this.EmployeeSalary = EmployeeSalary;
	}
	public double getEmployeeSalary()
	{
	    return EmployeeSalary;
	}
}
*/


public class Employee{

	 Integer EmployeeId;
	 String EmployeeName;
	 Double EmployeeSalary;
	 
	 public void setEmployeeId(int EmployeeId)
		{
		    this.EmployeeId = EmployeeId;
		}
		public Integer getEmployeeId()
		{
		    return EmployeeId;
		}
		 
		public void setEmployeeName(String EmployeeName)
		{
		    this.EmployeeName = EmployeeName;
		}
		public String getEmployeeName()
		{
		    return EmployeeName;
		}
		 
		public void setEmployeeSalary(double EmployeeSalary)
		{
		    this.EmployeeSalary = EmployeeSalary;
		}
		public Double getEmployeeSalary()
		{
		    return EmployeeSalary;
		}
	
}
